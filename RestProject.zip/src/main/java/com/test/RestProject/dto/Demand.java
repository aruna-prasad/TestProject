package com.test.RestProject.dto;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class Demand {
    private String productId;
    private Double quantity;

    public Demand(String productId, Double quantity) {
        this.productId = productId;
        this.quantity = quantity;
    }
}
