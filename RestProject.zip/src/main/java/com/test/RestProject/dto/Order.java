package com.test.RestProject.dto;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class Order {
    private String orderId;
    private String productId;
    private Double qty;

    public Order(String orderId, String productId, Double qty) {
        this.orderId = orderId;
        this.productId = productId;
        this.qty = qty;
    }
}
