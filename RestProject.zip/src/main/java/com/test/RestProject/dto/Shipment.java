package com.test.RestProject.dto;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class Shipment {

	private String orderId;
	private String shipmentId; 
	private String productId;
	private Date shipmentDate;
	private Double qty;
	
	public Shipment(String orderId, String shipmentId, String productId, Date shipmentDate, Double qty) {
		this.orderId = orderId;
		this.shipmentId = shipmentId;
		this.productId = productId;
		this.shipmentDate = shipmentDate;
		this.qty = qty;
	}
	
}
