package com.test.RestProject.dto;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class Supply {
    private String productId;
    private Double quantity;

    public Supply(String productId, Double quantity) {
        this.productId = productId;
        this.quantity = quantity;
    }
}
