package com.test.RestProject.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class RestProjectController {

    @Autowired
    RestProjectService service;

    //Problem 1
    @GetMapping("getOrderDetails")
    public List<Object> getOrderDetails(@RequestParam(required = true) String orderId){
        return service.orderDetails(orderId);
    }

    //Problem 2
    @GetMapping("getAvailability")
    public String getAvailability(@RequestParam(required = true) String productId){
        return service.fetchAvailability(productId);
    }

    //Problem 3
    @PostMapping
    public String updateSupply(){
        return service.updateSupplyDetails();
    }

}
