package com.test.RestProject.rest;

import com.test.RestProject.dto.*;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Date;
import java.util.concurrent.*;
import java.util.stream.Stream;

@Service
public class RestProjectService {

    //Problem 1
    public List<Object> orderDetails(String orderId){
        List<Object> orderDetails = new ArrayList<>();
        ExecutorService executor = Executors.newFixedThreadPool(5);
        List<Callable<Object>> callableList = new ArrayList<>();

        List<Future<Object>> results = null;
        try {
            callableList.add(() -> getOrder(orderId));
            callableList.add(() -> getShipment(orderId));
            results = executor.invokeAll(callableList);

            orderDetails.add(results.get(0).get());
            orderDetails.add(results.get(1).get());
        } catch (InterruptedException | ExecutionException e) {
            throw new RuntimeException(e);
        } finally {
            executor.shutdown();
        }
        return orderDetails;
    }

    private Order getOrder(String orderId) {
        Order orderObj1 = new Order ("Order1", "Prod1", 2.0);
        Order orderObj2 = new Order ("Order2", "Prod2", 12.0);

        List<Order> orderList = Arrays.asList(orderObj1, orderObj2);

        Order order = orderList.stream().filter(o -> o.getOrderId().equals(orderId)).findFirst().orElse(null);

        return order;
    }

    private Shipment getShipment(String orderId) {
        Shipment shipmentObj1 = new Shipment ("Order1", "Ship1", "Prod1", new Date (), 2.0);
        Shipment shipmentObj2 = new Shipment ("Order2", "Ship2", "Prod2", new Date (), 12.0);
        List<Shipment> shipmentList = Arrays.asList(shipmentObj1, shipmentObj2);

        Shipment shipment = shipmentList.stream().filter(s -> s.getOrderId().equals(orderId)).findFirst().orElse(null);

        return shipment;
    }

    //Problem 2
    public String fetchAvailability(String productId){
        List<Supply> supplyList = Stream.of(new Supply("Product1",Double.valueOf("10")),
                new Supply ("Product2", Double.valueOf("5"))).toList();

        List<Demand> demandList = Stream.of(new Demand("Product1",Double.valueOf("2")),
                new Demand ("Product2", Double.valueOf("5"))).toList();

        Supply supplyObj = supplyList.stream().filter(s -> s.getProductId().equals(productId)).findFirst().orElse(null);
        Demand demandObj = demandList.stream().filter(d -> d.getProductId().equals(productId)).findFirst().orElse(null);

        BigDecimal supply = (supplyObj!=null)?new BigDecimal(supplyObj.getQuantity()):BigDecimal.ZERO;
        BigDecimal demand = (demandObj!=null)?new BigDecimal(demandObj.getQuantity()):BigDecimal.ZERO;

        Double availability = supply.subtract(demand).doubleValue();

        return availability>0?availability.toString():"204 No Content";
    }

    //Problem 3
    public String updateSupplyDetails(){
        return null;
    }

}
